# **************************************************************************************************************
# Date: December 3, 2022
# Author: Lingbo Liu
# Description: This script is used to calculate the value f(d) of distance decay for 2SFCA and 2AVCA
# InputFeature : (1)supply layer, and its (2) ID,(3) supply amount(doctors or beds),(4) broadband speed

# OutputFeature: accessibility table
# **************************************************************************************************************
# Import system modules
import arcpy
import numpy as np
import pandas as pd
import math
from arcgis.features import GeoAccessor, GeoSeriesAccessor

# import matplotlib.pyplot as plt


# Get input parameters
matrixTable = arcpy.GetParameterAsText(0)
matrixID = arcpy.GetParameterAsText(1)
matrixCost = arcpy.GetParameterAsText(2)
fdij = arcpy.GetParameterAsText(3)
modeltype = arcpy.GetParameterAsText(4)
thresholdhead = float(arcpy.GetParameterAsText(5))
thresholdscale = float(arcpy.GetParameterAsText(6))
thresholdtail = arcpy.GetParameterAsText(7)
step3value = float(arcpy.GetParameterAsText(8))
beta = float(arcpy.GetParameterAsText(9))

# -------------Data transformed to SED--------------------#
matrix = pd.DataFrame.spatial.from_table(matrixTable)
df = matrix[[matrixID, matrixCost]]
arcpy.AddMessage("Data transformed to SED...")
if arcpy.Exists("temp"):
    arcpy.Delete_management("temp")

if thresholdtail != "":
    thresholdtail = float(thresholdtail)

# Delete a field if it exists in the input feature class (or layer).
def DelAField(FC, Field):
    flds = arcpy.ListFields(FC, Field)
    for fld in flds:
        if fld:
            arcpy.DeleteField_management(FC, Field)


def step3(x, threshold1, threshold2, bv):
    if x <= threshold1:
        v1 = 1
    elif x > threshold1 and x <= threshold2:
        v1 = bv
    else:
        v1 = 0
    return v1


def step2(x, threshold1):
    if x <= threshold1:
        v1 = 1
    else:
        v1 = 0
    return v1


def gravity(x, threshold1, threshold2, beta):
    # f(d) ->0 at d=threshold1,
    # f(d)=0, if d>threshold2
    h = threshold1 / 5
    if threshold2 == "":
        v1 = math.pow(((x + h) / h), (-1 * beta))
    else:
        if x <= threshold2:
            v1 = math.pow(((x + h) / h), (-1 * beta))
        else:
            v1 = 0
    return v1


def exponential(x, threshold1, threshold2, beta):
    h = threshold1
    if threshold2 == "":
        v1 = math.pow(math.e, (-1 * beta * (x * math.e / h)))
    else:
        if x <= threshold2:
            v1 = math.pow(math.e, (-1 * beta * (x * math.e / h)))
        else:
            v1 = 0
    return v1


def logistic(x, threshold1, beta):
    # f(d) ->0 at d=threshold1,
    h = threshold1 / 2
    v1 = 1 - 1 / (1 + math.pow(math.e, (-1 * beta * (x - h))))
    return v1


def tripHybridGravity(x, threshold1, threshold2, thresholdhead, beta):
    # f(d) =1 while d <= thresholdhead;
    # f(d) =0 while d > threshold1;
    h = threshold1 / 5
    if x <= thresholdhead:
        v1 = 1
    elif x > thresholdhead and x <= threshold2:
        v1 = math.pow(((x + h) / h), (-1 * beta))
    else:
        v1 = 0
    return v1


if modeltype == "2SFCA":
    df[fdij] = df[matrixCost].map(lambda x: step2(x, thresholdscale))
if modeltype == "E2SFCA":
    df[fdij] = df[matrixCost].map(
        lambda x: step3(x, thresholdscale, thresholdtail, step3value)
    )
if modeltype == "Gravity":
    df[fdij] = df[matrixCost].map(
        lambda x: gravity(x, thresholdscale, thresholdtail, beta)
    )
if modeltype == "Exponential":
    df[fdij] = df[matrixCost].map(
        lambda x: exponential(x, thresholdscale, thresholdtail, beta)
    )
if modeltype == "LogisticGrowth":
    df[fdij] = df[matrixCost].map(lambda x: logistic(x, thresholdscale, beta))
if modeltype == "TripleHybridGravity":
    df[fdij] = df[matrixCost].map(
        lambda x: tripHybridGravity(
            x, thresholdscale, thresholdtail, thresholdhead, beta
        )
    )

desc = arcpy.Describe(matrixTable)
gdbpath = desc.path
temp = gdbpath + "\\temp"
x = df.reset_index(drop=True)
z = np.rec.fromrecords(x.values, names=x.columns.tolist())
arcpy.da.NumPyArrayToTable(z, temp)
DelAField(matrixTable, fdij)
arcpy.JoinField_management(matrixTable, matrixID, temp, matrixID, fdij)
arcpy.Delete_management(temp)
arcpy.AddMessage("Save it as Table...")

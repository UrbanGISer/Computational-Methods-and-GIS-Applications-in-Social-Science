# **************************************************************************************************************
# Date: December 3, 2022
# Author: Lingbo Liu
# Description: This script is used to calculate healthcare service accessibility based on two-step virtual
#              floating catchment method ( 2SVCA)
# InputFeature 1: (1)supply layer, and its (2) ID,(3) supply amount(doctors or beds),(4) broadband speed
# InputFeature 2: (1)demand layer, and its (2) ID,(3) deamnd amount(population),(4) broadband speed,
#                 (5) broadband subscription rate
# InputFeature 3: (1)OD matrix table, and its (2) supply ID,(3) demand ID,(4) distance value,
# 				  (5) distance threshod
# OutputFeature: accessibility table
# **************************************************************************************************************

# Import system modules
import arcpy
import numpy as np
import pandas as pd
from arcgis.features import GeoAccessor, GeoSeriesAccessor

try:
    # Get input parameters
    supplyFL = arcpy.GetParameterAsText(0)
    supplyId = arcpy.GetParameterAsText(1)
    supplyDoc = arcpy.GetParameterAsText(2)
    # Add broadbandAcc 1/0 info for supply
    supplyBand = arcpy.GetParameterAsText(3)

    demandFL = arcpy.GetParameterAsText(4)
    demandId = arcpy.GetParameterAsText(5)
    demandPop = arcpy.GetParameterAsText(6)
    # Add broadbandAcc 1/0 and broadband subscription rate info for demand
    demandBand = arcpy.GetParameterAsText(7)
    demandBandAvail = arcpy.GetParameterAsText(8)

    matrixTable = arcpy.GetParameterAsText(9)
    matrixSupplyId = arcpy.GetParameterAsText(10)
    matrixDemandId = arcpy.GetParameterAsText(11)
    matrixCost = arcpy.GetParameterAsText(12)
    Threshold = float(arcpy.GetParameterAsText(13))
    outputTable = arcpy.GetParameterAsText(14)

    if arcpy.Exists("temp"):
        arcpy.Delete_management("temp")

    # -------------Data transformed to SED--------------------#
    supply = pd.DataFrame.spatial.from_featureclass(supplyFL)
    demand = pd.DataFrame.spatial.from_featureclass(demandFL)
    matrix = pd.DataFrame.spatial.from_table(matrixTable)
    arcpy.AddMessage("Data transformed to SED...")

    supply1 = supply[[supplyId, supplyDoc, supplyBand]].rename(
        columns={supplyId: "SID", supplyDoc: "Pcp", supplyBand: "bi"}
    )
    demand1 = demand[[demandId, demandPop, demandBand, demandBandAvail]].rename(
        columns={
            demandId: "DID",
            demandPop: "Pop",
            demandBand: "bk",
            demandBandAvail: "bandR",
        }
    )
    matrix1 = matrix[[matrixSupplyId, matrixDemandId, matrixCost]].rename(
        columns={matrixSupplyId: "SID", matrixDemandId: "DID", matrixCost: "Dist"}
    )

    matrix1 = matrix1[matrix1.Dist <= Threshold]
    matrixf = pd.merge(matrix1, supply1, on="SID")
    matrixf = pd.merge(matrixf, demand1, on="DID")
    arcpy.AddMessage("Data Merged...")

    # -------------Calculation--------------------------------#
    matrixf["wpop"] = matrixf.Pop
    sumpop = (
        matrixf[["SID", "wpop"]]
        .groupby(["SID"])
        .sum()
        .reset_index()
        .rename(columns={"index": "SID", "wpop": "Sumpop"})
    )
    matrixf = pd.merge(matrixf, sumpop, on="SID")
    matrixf["docpopr"] = 1000 * matrixf.Pcp / matrixf.Sumpop
    sumdocpopr = (
        matrixf[["DID", "docpopr"]]
        .groupby(["DID"])
        .sum()
        .reset_index()
        .rename(columns={"index": "DID"})
    )
    demand = pd.merge(demand, sumdocpopr, how="left", left_on=demandId, right_on="DID")
    demand["docpopr"] = demand["docpopr"].fillna(0)
    demand.DID = demand[demandId]
    acc = demand[["DID", "docpopr"]]
    arcpy.AddMessage("Calculation Succeed...")
    # arcpy.CopyFeatures_management(acc, "temp")
    # -------------Save Result--------------------------------#
    # temp = "temp"
    # desc = arcpy.Describe(supplyFL)
    # gdbpath = desc.path
    # arcpy.TableToTable_conversion(acc, gdbpath, outputTable)
    x = acc.reset_index(drop=True)
    z = np.rec.fromrecords(x.values, names=x.columns.tolist())
    arcpy.da.NumPyArrayToTable(z, outputTable)
    arcpy.AddMessage("Save it as Table...")

    # arcpy.JoinField_management(
    #     demandFL,
    #     demandId,
    #     "temp",
    #     "DID",
    #     "docpopr",
    # )
    # arcpy.Delete_management("temp")
    # arcpy.AddMessage("Attached Result to Demand Layer...")

except Exception as e:
    print(e.message)
